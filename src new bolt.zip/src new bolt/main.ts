import { bootstrapApplication } from '@angular/platform-browser';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { App } from './app/app.component';
import { AuthGuard } from './app/core/guards/auth.guard';
import { TenantInterceptor } from './app/core/interceptors/tenant.interceptor';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

bootstrapApplication(App, {
  providers: [
    provideAnimations(),
    provideHttpClient(
      withInterceptors([])
    ),
    provideRouter([
      {
        path: 'login',
        loadComponent: () => import('./app/features/auth/login.component')
          .then(m => m.LoginComponent)
      },
      {
        path: 'dashboard',
        canActivate: [AuthGuard],
        loadChildren: () => import('./app/features/dashboard/dashboard.routes')
          .then(m => m.DASHBOARD_ROUTES)
      },
      {
        path: 'students',
        canActivate: [AuthGuard],
        loadChildren: () => import('./app/features/students/students.routes')
          .then(m => m.STUDENTS_ROUTES)
      },
      {
        path: 'results',
        canActivate: [AuthGuard],
        loadChildren: () => import('./app/features/results/results.routes')
          .then(m => m.RESULTS_ROUTES)
      },
      {
        path: 'timetable',
        canActivate: [AuthGuard],
        loadComponent: () => import('./app/features/timetable/timetable.component')
          .then(m => m.TimetableComponent)
      },
      {
        path: 'finance',
        canActivate: [AuthGuard],
        loadComponent: () => import('./app/features/finance/finance-dashboard.component')
          .then(m => m.FinanceDashboardComponent)
      },
      {
        path: 'visitors',
        canActivate: [AuthGuard],
        loadComponent: () => import('./app/features/visitor/visitor-log.component')
          .then(m => m.VisitorLogComponent)
      },
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      }
    ]), provideAnimationsAsync()
  ]
});