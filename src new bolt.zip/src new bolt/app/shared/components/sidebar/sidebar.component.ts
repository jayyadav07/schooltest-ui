import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatExpansionModule } from '@angular/material/expansion';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MenuService } from '../../../core/services/menu.service';
import { MenuItem } from '../../../core/models/menu-item.model';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    MatExpansionModule
  ],
  template: `
    <mat-nav-list>
      @for (item of menuItems; track item.label) {
        @if (item.children) {
          <mat-expansion-panel class="mat-elevation-z0">
            <mat-expansion-panel-header>
              <mat-panel-title>
                <mat-icon>{{item.icon}}</mat-icon>
                {{item.label}}
              </mat-panel-title>
            </mat-expansion-panel-header>
            @for (child of item.children; track child.label) {
              <a mat-list-item [routerLink]="child.route">
                {{child.label}}
              </a>
            }
          </mat-expansion-panel>
        } @else {
          <a mat-list-item [routerLink]="item.route">
            <mat-icon>{{item.icon}}</mat-icon>
            {{item.label}}
          </a>
        }
      }
    </mat-nav-list>
  `,
  styles: [`
    :host {
      display: block;
      width: 250px;
    }
    mat-nav-list {
      padding: 0;
    }
    .mat-expansion-panel {
      box-shadow: none;
      background: transparent;
    }
    .mat-expansion-panel-header {
      padding: 0 16px;
    }
    mat-panel-title {
      align-items: center;
      display: flex;
      gap: 16px;
    }
    a[mat-list-item] {
      padding-left: 16px;
    }
  `],
  animations: [
    trigger('slideInOut', [
      state('void', style({
        transform: 'translateX(-100%)'
      })),
      state('*', style({
        transform: 'translateX(0)'
      })),
      transition('void <=> *', animate('200ms ease-in-out'))
    ])
  ],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SidebarComponent {
  menuItems: MenuItem[];

  constructor(menuService: MenuService) {
    this.menuItems = menuService.getMenuItems();
  }
}