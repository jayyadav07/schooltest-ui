import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { Transaction } from '../../core/models/finance.model';

@Component({
  selector: 'app-finance-dashboard',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatTableModule],
  template: `
    <div class="finance-grid">
      <mat-card class="summary-card">
        <mat-card-header>
          <mat-card-title>Total Income</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <h2>₹{{totalIncome}}</h2>
        </mat-card-content>
      </mat-card>

      <mat-card class="summary-card">
        <mat-card-header>
          <mat-card-title>Total Expenses</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <h2>₹{{totalExpenses}}</h2>
        </mat-card-content>
      </mat-card>

      <mat-card class="transactions-card">
        <mat-card-header>
          <mat-card-title>Recent Transactions</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <table mat-table [dataSource]="recentTransactions">
            <ng-container matColumnDef="date">
              <th mat-header-cell *matHeaderCellDef>Date</th>
              <td mat-cell *matCellDef="let transaction">
                {{transaction.date | date}}
              </td>
            </ng-container>

            <ng-container matColumnDef="type">
              <th mat-header-cell *matHeaderCellDef>Type</th>
              <td mat-cell *matCellDef="let transaction">
                {{transaction.type}}
              </td>
            </ng-container>

            <ng-container matColumnDef="amount">
              <th mat-header-cell *matHeaderCellDef>Amount</th>
              <td mat-cell *matCellDef="let transaction">
                ₹{{transaction.amount}}
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
            <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
          </table>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .finance-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 20px;
      padding: 20px;
    }
    .summary-card {
      text-align: center;
    }
    .summary-card h2 {
      font-size: 2rem;
      color: #1976d2;
    }
    .transactions-card {
      grid-column: 1 / -1;
    }
    table {
      width: 100%;
    }
  `]
})
export class FinanceDashboardComponent implements OnInit {
  totalIncome = 150000;
  totalExpenses = 75000;
  displayedColumns = ['date', 'type', 'amount'];
  recentTransactions: Transaction[] = [
    {
      id: 1,
      type: 'income',
      amount: 25000,
      category: 'Fees',
      description: 'Student fees collection',
      date: new Date()
    },
    // Add more mock transactions
  ];

  ngOnInit() {
    // In a real app, fetch financial data from a service
  }
}