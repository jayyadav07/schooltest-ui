import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MockDataService } from '../../core/services/mock-data.service';
import { Student } from '../../core/models/student.model';

@Component({
  selector: 'app-students-list',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatCardModule],
  template: `
    <mat-card>
      <mat-card-header>
        <mat-card-title>Students List</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <table mat-table [dataSource]="students" class="mat-elevation-z8">
          <ng-container matColumnDef="rollNumber">
            <th mat-header-cell *matHeaderCellDef>Roll No.</th>
            <td mat-cell *matCellDef="let student">{{student.rollNumber}}</td>
          </ng-container>

          <ng-container matColumnDef="name">
            <th mat-header-cell *matHeaderCellDef>Name</th>
            <td mat-cell *matCellDef="let student">{{student.name}}</td>
          </ng-container>

          <ng-container matColumnDef="class">
            <th mat-header-cell *matHeaderCellDef>Class</th>
            <td mat-cell *matCellDef="let student">{{student.class}}</td>
          </ng-container>

          <ng-container matColumnDef="section">
            <th mat-header-cell *matHeaderCellDef>Section</th>
            <td mat-cell *matCellDef="let student">{{student.section}}</td>
          </ng-container>

          <ng-container matColumnDef="attendance">
            <th mat-header-cell *matHeaderCellDef>Attendance</th>
            <td mat-cell *matCellDef="let student">{{student.attendance}}%</td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
        </table>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    table {
      width: 100%;
    }
    .mat-mdc-card {
      margin: 20px;
    }
  `]
})
export class StudentsListComponent {
  students: Student[];
  displayedColumns: string[] = ['rollNumber', 'name', 'class', 'section', 'attendance'];

  constructor(private mockData: MockDataService) {
    this.students = this.mockData.getStudents();
  }
}