import { Routes } from '@angular/router';
import { StudentsListComponent } from './students-list.component';
import { StudentProfileComponent } from './student-profile.component';
import { AttendanceComponent } from '../attendance/attendance.component';

export const STUDENTS_ROUTES: Routes = [
  { path: 'view', component: StudentsListComponent },
  { path: 'profile/:id', component: StudentProfileComponent },
  { path: 'attendance', component: AttendanceComponent }
];