import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatListModule } from '@angular/material/list';
import { Student, Result } from '../../core/models/student.model';
import { MockDataService } from '../../core/services/mock-data.service';

@Component({
  selector: 'app-student-profile',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatTabsModule, MatListModule],
  template: `
    <div class="profile-container">
      <mat-card class="profile-card">
        <mat-card-header>
          <mat-card-title>{{student?.name}}</mat-card-title>
          <mat-card-subtitle>Roll Number: {{student?.rollNumber}}</mat-card-subtitle>
        </mat-card-header>
        <mat-card-content>
          <mat-tab-group>
            <mat-tab label="Details">
              <div class="details-section">
                <h3>Personal Information</h3>
                <mat-list>
                  <mat-list-item>Class: {{student?.class}}</mat-list-item>
                  <mat-list-item>Section: {{student?.section}}</mat-list-item>
                  <mat-list-item>Attendance: {{student?.attendance}}%</mat-list-item>
                  <mat-list-item>Performance: {{student?.performance}}%</mat-list-item>
                </mat-list>
              </div>
            </mat-tab>
            <mat-tab label="Results">
              <div class="results-section">
                <h3>Academic Results</h3>
                @for (result of results; track result.id) {
                  <div class="result-item">
                    <p><strong>{{result.subject}}</strong></p>
                    <p>Marks: {{result.marks}}</p>
                    <p>Grade: {{result.grade}}</p>
                    <p>Term: {{result.term}}</p>
                  </div>
                }
              </div>
            </mat-tab>
          </mat-tab-group>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .profile-container {
      padding: 20px;
    }
    .profile-card {
      max-width: 800px;
      margin: 0 auto;
    }
    .details-section, .results-section {
      padding: 20px;
    }
    .result-item {
      border: 1px solid #ddd;
      padding: 15px;
      margin: 10px 0;
      border-radius: 4px;
    }
    .result-item p {
      margin: 5px 0;
    }
  `]
})
export class StudentProfileComponent {
  student?: Student;
  results: Result[] = [];

  constructor(private mockData: MockDataService) {
    // In a real app, we would get the student ID from the route params
    const studentId = 1;
    this.student = this.mockData.getStudentById(studentId);
    this.results = this.mockData.getResultsByStudentId(studentId);
  }
}