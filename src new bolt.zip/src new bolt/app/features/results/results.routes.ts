import { Routes } from '@angular/router';
import { ResultsListComponent } from './results-list.component';

export const RESULTS_ROUTES: Routes = [
  { path: 'view', component: ResultsListComponent }
];