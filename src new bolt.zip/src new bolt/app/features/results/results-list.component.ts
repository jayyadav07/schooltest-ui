import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MockDataService } from '../../core/services/mock-data.service';
import { Result } from '../../core/models/student.model';

@Component({
  selector: 'app-results-list',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatCardModule],
  template: `
    <mat-card>
      <mat-card-header>
        <mat-card-title>Results</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <table mat-table [dataSource]="results" class="mat-elevation-z8">
          <ng-container matColumnDef="student">
            <th mat-header-cell *matHeaderCellDef>Student</th>
            <td mat-cell *matCellDef="let result">{{getStudentName(result.studentId)}}</td>
          </ng-container>

          <ng-container matColumnDef="subject">
            <th mat-header-cell *matHeaderCellDef>Subject</th>
            <td mat-cell *matCellDef="let result">{{result.subject}}</td>
          </ng-container>

          <ng-container matColumnDef="marks">
            <th mat-header-cell *matHeaderCellDef>Marks</th>
            <td mat-cell *matCellDef="let result">{{result.marks}}</td>
          </ng-container>

          <ng-container matColumnDef="grade">
            <th mat-header-cell *matHeaderCellDef>Grade</th>
            <td mat-cell *matCellDef="let result">{{result.grade}}</td>
          </ng-container>

          <ng-container matColumnDef="term">
            <th mat-header-cell *matHeaderCellDef>Term</th>
            <td mat-cell *matCellDef="let result">{{result.term}}</td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
        </table>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    table {
      width: 100%;
    }
    .mat-mdc-card {
      margin: 20px;
    }
  `]
})
export class ResultsListComponent {
  results: Result[];
  displayedColumns: string[] = ['student', 'subject', 'marks', 'grade', 'term'];

  constructor(private mockData: MockDataService) {
    this.results = this.mockData.getResults();
  }

  getStudentName(studentId: number): string {
    const student = this.mockData.getStudentById(studentId);
    return student ? student.name : 'Unknown';
  }
}