import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { TimeSlot } from '../../core/models/timetable.model';

@Component({
  selector: 'app-timetable',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatCardModule],
  template: `
    <mat-card>
      <mat-card-header>
        <mat-card-title>Class Timetable</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <div class="timetable-grid">
          @for (day of days; track day) {
            <div class="day-column">
              <h3>{{day}}</h3>
              @for (slot of getTimeSlots(day); track slot.id) {
                <div class="time-slot">
                  <p class="time">{{slot.startTime}} - {{slot.endTime}}</p>
                  <p class="subject">{{slot.subject}}</p>
                </div>
              }
            </div>
          }
        </div>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .timetable-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      padding: 20px;
    }
    .day-column {
      border: 1px solid #ddd;
      padding: 10px;
      border-radius: 4px;
    }
    .time-slot {
      background: #f5f5f5;
      margin: 10px 0;
      padding: 10px;
      border-radius: 4px;
    }
    .time {
      color: #666;
      margin: 0;
      font-size: 0.9em;
    }
    .subject {
      margin: 5px 0 0;
      font-weight: bold;
    }
  `]
})
export class TimetableComponent {
  days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  mockTimeSlots: TimeSlot[] = [
    {
      id: 1,
      day: 'Monday',
      startTime: '09:00',
      endTime: '10:00',
      subject: 'Mathematics',
      teacherId: 1,
      classId: 1,
      section: 'A'
    },
    {
      id: 2,
      day: 'Monday',
      startTime: '10:00',
      endTime: '11:00',
      subject: 'Science',
      teacherId: 2,
      classId: 1,
      section: 'A'
    },
    {
      id: 3,
      day: 'Monday',
      startTime: '11:15',
      endTime: '12:15',
      subject: 'English',
      teacherId: 3,
      classId: 1,
      section: 'A'
    },
    {
      id: 4,
      day: 'Tuesday',
      startTime: '09:00',
      endTime: '10:00',
      subject: 'Physics',
      teacherId: 4,
      classId: 1,
      section: 'A'
    },
    {
      id: 5,
      day: 'Tuesday',
      startTime: '10:00',
      endTime: '11:00',
      subject: 'Chemistry',
      teacherId: 5,
      classId: 1,
      section: 'A'
    }
  ];

  getTimeSlots(day: string): TimeSlot[] {
    return this.mockTimeSlots.filter(slot => slot.day === day);
  }
}