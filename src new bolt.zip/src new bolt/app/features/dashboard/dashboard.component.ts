import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MockDataService } from '../../core/services/mock-data.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, MatCardModule],
  template: `
    <div class="dashboard-grid">
      <mat-card>
        <mat-card-header>
          <mat-card-title>Total Students</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <h2>{{totalStudents}}</h2>
        </mat-card-content>
      </mat-card>

      <mat-card>
        <mat-card-header>
          <mat-card-title>Average Attendance</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <h2>{{averageAttendance}}%</h2>
        </mat-card-content>
      </mat-card>

      <mat-card>
        <mat-card-header>
          <mat-card-title>Average Performance</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <h2>{{averagePerformance}}%</h2>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .dashboard-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      padding: 20px;
    }
    mat-card {
      text-align: center;
    }
    h2 {
      font-size: 2.5rem;
      margin: 20px 0;
      color: #1976d2;
    }
  `]
})
export class DashboardComponent {
  totalStudents: number;
  averageAttendance: number;
  averagePerformance: number;

  constructor(private mockData: MockDataService) {
    const students = this.mockData.getStudents();
    this.totalStudents = students.length;
    this.averageAttendance = Math.round(
      students.reduce((acc, student) => acc + student.attendance, 0) / students.length
    );
    this.averagePerformance = Math.round(
      students.reduce((acc, student) => acc + student.performance, 0) / students.length
    );
  }
}