import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { Visitor } from '../../core/models/visitor.model';

@Component({
  selector: 'app-visitor-log',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatCardModule, MatButtonModule],
  template: `
    <mat-card>
      <mat-card-header>
        <mat-card-title>Visitor Log</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <table mat-table [dataSource]="visitors">
          <ng-container matColumnDef="name">
            <th mat-header-cell *matHeaderCellDef>Name</th>
            <td mat-cell *matCellDef="let visitor">{{visitor.name}}</td>
          </ng-container>

          <ng-container matColumnDef="purpose">
            <th mat-header-cell *matHeaderCellDef>Purpose</th>
            <td mat-cell *matCellDef="let visitor">{{visitor.purpose}}</td>
          </ng-container>

          <ng-container matColumnDef="entryTime">
            <th mat-header-cell *matHeaderCellDef>Entry Time</th>
            <td mat-cell *matCellDef="let visitor">
              {{visitor.entryTime | date:'medium'}}
            </td>
          </ng-container>

          <ng-container matColumnDef="status">
            <th mat-header-cell *matHeaderCellDef>Status</th>
            <td mat-cell *matCellDef="let visitor">
              <span [class]="'status-' + visitor.status">
                {{visitor.status}}
              </span>
            </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
        </table>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    table {
      width: 100%;
    }
    .status-in {
      color: green;
      font-weight: bold;
    }
    .status-out {
      color: #666;
    }
    mat-card {
      margin: 20px;
    }
  `]
})
export class VisitorLogComponent implements OnInit {
  displayedColumns = ['name', 'purpose', 'entryTime', 'status'];
  visitors: Visitor[] = [
    {
      id: 1,
      name: 'John Smith',
      purpose: 'Parent Meeting',
      contactNumber: '1234567890',
      entryTime: new Date(),
      status: 'in'
    },
    // Add more mock visitors
  ];

  ngOnInit() {
    // In a real app, fetch visitor data from a service
  }
}