import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { Student } from '../../core/models/student.model';
import { MockDataService } from '../../core/services/mock-data.service';

@Component({
  selector: 'app-attendance',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatCardModule, MatButtonModule],
  template: `
    <mat-card>
      <mat-card-header>
        <mat-card-title>Daily Attendance</mat-card-title>
        <mat-card-subtitle>{{currentDate | date:'fullDate'}}</mat-card-subtitle>
      </mat-card-header>
      <mat-card-content>
        <table mat-table [dataSource]="students" class="mat-elevation-z8">
          <ng-container matColumnDef="rollNumber">
            <th mat-header-cell *matHeaderCellDef>Roll No.</th>
            <td mat-cell *matCellDef="let student">{{student.rollNumber}}</td>
          </ng-container>

          <ng-container matColumnDef="name">
            <th mat-header-cell *matHeaderCellDef>Name</th>
            <td mat-cell *matCellDef="let student">{{student.name}}</td>
          </ng-container>

          <ng-container matColumnDef="class">
            <th mat-header-cell *matHeaderCellDef>Class</th>
            <td mat-cell *matCellDef="let student">{{student.class}}</td>
          </ng-container>

          <ng-container matColumnDef="attendance">
            <th mat-header-cell *matHeaderCellDef>Attendance</th>
            <td mat-cell *matCellDef="let student">
              <button mat-button color="primary" (click)="markAttendance(student, true)">Present</button>
              <button mat-button color="warn" (click)="markAttendance(student, false)">Absent</button>
            </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
        </table>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    table {
      width: 100%;
    }
    .mat-mdc-card {
      margin: 20px;
    }
    .mat-column-attendance {
      display: flex;
      gap: 8px;
    }
  `]
})
export class AttendanceComponent {
  students: Student[];
  displayedColumns = ['rollNumber', 'name', 'class', 'attendance'];
  currentDate = new Date();

  constructor(private mockData: MockDataService) {
    this.students = this.mockData.getStudents();
  }

  markAttendance(student: Student, present: boolean) {
    // In a real app, this would update the attendance in the backend
    console.log(`Marking ${student.name} as ${present ? 'present' : 'absent'}`);
  }
}