import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TenantService } from '../services/tenant.service';
import { take, switchMap } from 'rxjs/operators';

@Injectable()
export class TenantInterceptor implements HttpInterceptor {
  constructor(private tenantService: TenantService) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return this.tenantService.currentTenant$.pipe(
      take(1),
      switchMap(tenant => {
        if (tenant) {
          request = request.clone({
            setHeaders: {
              'X-Tenant-ID': tenant.id
            }
          });
        }
        return next.handle(request);
      })
    );
  }
}