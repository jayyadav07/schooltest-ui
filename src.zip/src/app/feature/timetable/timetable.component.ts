import { Component } from '@angular/core';

@Component({
  selector: 'app-timetable',
  imports: [],
  templateUrl: './timetable.component.html',
  styleUrl: './timetable.component.scss'
})
export class TimetableComponent {

}
