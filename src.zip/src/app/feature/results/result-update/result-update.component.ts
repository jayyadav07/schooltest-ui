import { Component } from '@angular/core';

@Component({
  selector: 'app-result-update',
  imports: [],
  templateUrl: './result-update.component.html',
  styleUrl: './result-update.component.scss'
})
export class ResultUpdateComponent {

}
