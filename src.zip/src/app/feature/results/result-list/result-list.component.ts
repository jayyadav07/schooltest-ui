import { Component } from '@angular/core';

@Component({
  selector: 'app-result-list',
  imports: [],
  templateUrl: './result-list.component.html',
  styleUrl: './result-list.component.scss'
})
export class ResultListComponent {

}
