import { Component } from '@angular/core';

@Component({
  selector: 'app-vehicle-register',
  imports: [],
  templateUrl: './vehicle-register.component.html',
  styleUrl: './vehicle-register.component.scss'
})
export class VehicleRegisterComponent {

}
