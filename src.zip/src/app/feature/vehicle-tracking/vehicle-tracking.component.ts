import { Component } from '@angular/core';

@Component({
  selector: 'app-vehicle-tracking',
  imports: [],
  templateUrl: './vehicle-tracking.component.html',
  styleUrl: './vehicle-tracking.component.scss'
})
export class VehicleTrackingComponent {

}
