import { Component } from '@angular/core';

@Component({
  selector: 'app-attendance',
  imports: [],
  templateUrl: './attendance.component.html',
  styleUrl: './attendance.component.scss'
})
export class AttendanceComponent {

}
