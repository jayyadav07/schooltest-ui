import { Component } from '@angular/core';

@Component({
  selector: 'app-finance',
  imports: [],
  templateUrl: './finance.component.html',
  styleUrl: './finance.component.scss'
})
export class FinanceComponent {

}
