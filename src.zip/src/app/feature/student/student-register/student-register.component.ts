import { Component } from '@angular/core';

@Component({
  selector: 'app-student-register',
  imports: [],
  templateUrl: './student-register.component.html',
  styleUrl: './student-register.component.scss'
})
export class StudentRegisterComponent {

}
