import { Component } from '@angular/core';

@Component({
  selector: 'app-visitor',
  imports: [],
  templateUrl: './visitor.component.html',
  styleUrl: './visitor.component.scss'
})
export class VisitorComponent {

}
